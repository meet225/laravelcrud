<?php

namespace App\Http\Controllers;

use App\Models\Cart;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Validator;
use Response;
class CartController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
         
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
         try{
            $validator = Validator::make($request->all(), [
                'cart_id' => 'required',
                'product_id' => 'required',
                'quantity' => 'required'
            ]);
     
            if ($validator->fails()) {
                return Response::json(['errors' => $validator->errors()], 400);
            }
            if(isset($request->user_id)&& !empty($request->user_id)){
                $user_id= $request->user_id;
            }else{
                $user_id= null;
            }

            $values = array('cart_id' => $request->cart_id,'user_id' => $user_id,'product_id' => $request->product_id,'quantity' => $request->quantity);

             DB::table('carts')->insert($values);           
            
            return Response::json(['data' => 'Cart added successfully'],200);
     
        }catch(Exception $e){
            return Response::json(['errors' => 'Bad Request'], 400);
        }
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Cart  $cart
     * @return \Illuminate\Http\Response
     */
    public function show($cart_id)
    {
         try{
            
            $Cart = Cart::select('id','cart_id','user_id','product_id','quantity')->where('cart_id', $cart_id)->first();  
           
            return Response::json(['data' => $Cart],200);
            }catch(Exception $e){
            return Response::json(['errors' => 'Bad Request'], 400);
         }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Cart  $cart
     * @return \Illuminate\Http\Response
     */
    public function edit(Cart $cart)
    {
        
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Cart  $cart
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {           
        try{     
            $validator = Validator::make($request->all(), [
                'cart_id' => 'required',
                'product_id' => 'required',
                'quantity' => 'required'
            ]);
     
            if ($validator->fails()) {
                return Response::json(['errors' => $validator->errors()],400);
            }
            if ($request->quantity==0) {
                # code... delect form cart when quanty 0
                $product = DB::table('carts')->where('product_id',$request->product_id)->orWhere('cart_id',$request->cart_id)->delete();
            }else{
            
                DB::table('carts')
                ->where('cart_id', $request->cart_id)
                ->orWhere('product_id', $request->product_id)            
                ->update(['quantity' => $request->quantity]);
                // ->update(array('quantity' => $request->quantity));
            }
            
             return Response::json(['data' => 'Cart updated successfully'],200);
           }catch(Exception $e){
             return Response::json(['errors' => 'Bad Request'], 400);
          }
    }
       public function sucess(Request $request){
          try{ 
             $validator = Validator::make($request->all(), [
                'cart_id' => 'required',
                'user_id' => 'required'
             ]);           
            
            $users = DB::table('users')->where('id',$request->user_id)->value('id');
                if ($users === null ) {
                   // user doesn't exist
                    return Response::json(['data' => 'Please login Or Register'], 400);
                }else{

                    $product = DB::table('carts')->where('cart_id', '=', $request->cart_id)->delete();
                     return Response::json(['data' => 'Order successfully add'],200);
                }
           
           
            }catch(Exception $e){
            return Response::json(['errors' => 'Bad Request'], 400);
         }
       }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Cart  $cart
     * @return \Illuminate\Http\Response
     */
    public function destroy(Cart $cart)
    {
        //
    }
}

<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Response;
// use App\Product;
use App\Models\Product;
use Validator;
use Illuminate\Support\Facades\DB;

class RestApiController extends Controller
{
	public function list(){
	    try{
		    // $products = Product::select('id','name','category','brand','color','price','image','quantity')->get();
		     $products = DB::select('SELECT * FROM products WHERE 1');
		     return Response::json(['data' => $products],200);

		    }catch(Exception $e){
		   
		   return Response::json(['errors' => 'Bad Request'], 400);
		  }
     }

 
	public function create(Request $request){
	 
	    try{
	        $validator = Validator::make($request->all(), [
	            'name' => 'required|min:2',
	            'category' => 'required',
	            'brand' => 'required',
	            'color' => 'required',
	            'price' => 'required',
	            'image' => 'required',
	            'quantity' => 'required'
	        ]);
	 
	        if ($validator->fails()) {
	            return Response::json(['errors' => $validator->errors()], 400);
	        }

	        $values = array('name' => $request->name,'category' => $request->category,'brand' => $request->brand,'color' => $request->color,'price' => $request->price,'image' => $request->image,'quantity' => $request->quantity);

			 DB::table('products')->insert($values);	       
	        
	        return Response::json(['data' => 'added successfully'],200);
	 
	    }catch(Exception $e){
	        return Response::json(['errors' => 'Bad Request'], 400);
	    }
	 
	}

	public function show($id){
         try{
            $products = DB::select('SELECT * FROM products')->where('id', $id)->first();
            return Response::json(['data' => $product],200);
            }catch(Exception $e){
            return Response::json(['errors' => 'Bad Request'], 400);
         }
    }

	    public function update($id, Request $request){
	     try{
	     	if(empty($id)){
	     		 return Response::json(['errors' => 'Id not found'],400);
	     	}
	     	// print_r($request->all());
	     	// exit();
	            
	        $validator = Validator::make($request->all(), [
	            'name' => 'required|min:2',
	            'category' => 'required',
	            'brand' => 'required',
	            'color' => 'required',
	            'price' => 'required',
	            'image' => 'required',
	            'quantity' => 'required'
	        ]);
	 
	        if ($validator->fails()) {
	            return Response::json(['errors' => $validator->errors()],400);
	        }
	 		
	 		DB::table('products')
            ->where('id', $id)
            ->update(array('name' => $request->name,'category' => $request->category,'brand' => $request->brand,'color' => $request->color,'price' => $request->price,'image' => $request->image,'quantity' => $request->quantity));
	        
	         return Response::json(['data' => 'updated successfully'],200);
	       }catch(Exception $e){
	         return Response::json(['errors' => 'Bad Request'], 400);
	      }
	     
	   }


		public function delete($id){
		    try{
		        // $product = Product::where('id', $id)->delete();

		        $product = DB::table('products')->where('id', '=', $id)->delete();
		        
		        return Response::json(['data' => 'deleted successfully'],200);
		    }catch(Exception $e){
		        return Response::json(['errors' => 'Bad Request'], 400);
		    }
		}
}

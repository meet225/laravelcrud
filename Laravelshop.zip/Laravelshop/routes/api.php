<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

// Route::middleware('auth:api')->get('/user', function (Request $request) {
//     return $request->user();
// });
 
Route::get('apiProductList', 'RestApiController@list');
Route::post('apiProductNew', 'RestApiController@create');
Route::get('apiProductShow/{id}', 'RestApiController@show');
Route::post('apiProductUpdate/{id}', 'RestApiController@update');
Route::delete('apiProductDelete/{id}', 'RestApiController@delete');

Route::get('apiCartShow/{id}', 'CartController@show');
Route::post('apiCartNew', 'CartController@create');
Route::post('apiCarUpdate', 'CartController@update');
Route::post('apiCarSucess', 'CartController@sucess');